/**
 * 第14周作业
 * 作业名称：分支判断
 * 作业要求格式：
 * 1.截图代码及运行效果到word上，截图打自己的标识水印
 *      word命名格式：班级-周次-序号后2位-姓名-作业名称.doc
 *      例如:23移动2-13-08-张海鹏-分支循环.doc
 * 2.周四之前完成交学委，学委上交老师邮箱wnetx126@126.com
 * 作者：23移动2杜明川
 */

import java.util.Scanner;

public class Du {
    //      23移动2班杜明川
    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);
//        Random r = new Random();
//      23移动2班杜明川
        System.out.print("请输入数字（1~12）：");
        int i = x.nextInt();
        switch (i) {
            case 1:
                System.out.println("香菇滑鸡");
                break;//23移动2班杜明川
            case 2:
                System.out.println("烤鸭");
                break;//23移动2班杜明川
            case 3:
                System.out.println("鱼香肉丝");
                break;//23移动2班杜明川
            case 4:
                System.out.println("宫保鸡丁");
                break;//23移动2班杜明川
            case 5:
                System.out.println("麻婆豆腐");
                break;//23移动2班杜明川
            case 6:
                System.out.println("炒面");
                break;//23移动2班杜明川
            case 7:
                System.out.println("烤串");
                break;//23移动2班杜明川
            case 8:
                System.out.println("拔丝苹果");
                break;//23移动2班杜明川
            case 9:
                System.out.println("糖醋排骨");
                break;//23移动2班杜明川
            case 10:
                System.out.println("红烧肉");
                break;//23移动2班杜明川
            case 11:
                System.out.println("饺子");
                break;//23移动2班杜明川
            case 12:
                System.out.println("麻辣烫");
                break;//23移动2班杜明川
        }
        System.out.println();
//        23移动二班杜明川

//        作业二 For循环

        int p = 0;
        for (int o = 0; o < 101; o++) {
            p += o;
            System.out.print("第" + o + "次累加：");
            System.out.println(p);
        }
        System.out.println();

        int p1 = 0;
        int p2 = 0;
        for (int o = 2; o < 101; o += 2) {
            p1 += o;
            p2++;
            System.out.print("第" + p2 + "次偶数累加：");
            System.out.println(p1);
        }




        /*for (int b = 1; b < 100; b++) {
            int a = r.nextInt(101);
            System.out.println("第" + b +"个数字:"+ a);
        }*/



        /*System.out.print("请输入1~7的整数：");
        int a = x.nextInt();

        switch (a) {
            case 1:
                System.out.println("星期一");
                break;
            case 2:
                System.out.println("星期二");
                break;
            case 3:
                System.out.println("星期三");
                break;
            case 4:
                System.out.println("星期四");
                break;
            case 5:
                System.out.println("星期五");
                break;
            case 6:
                System.out.println("星期六");
                break;
            case 7:
                System.out.println("星期日");
                break;
        }
        System.out.println();*/


        /*System.out.println("一个月有多少天");
        System.out.println("请输入月份");
        int b = x.nextInt();
        switch (b) {
            case 1,3,5,7,8,10,12:
                System.out.println("31");
                break;
            case 2:
                System.out.println("28");
                break;
            case 4,6,9,11:
                System.out.println("30");
                break;


        }*/





        /*System.out.print("请输入0~100的整数:");
        int b = x.nextInt();

        if (b >= 90) {
            System.out.println("A");
        } else if (b >= 80) {
            System.out.println("B");
        } else if (b >= 70) {
            System.out.println("C");
        } else if (b >= 60) {
            System.out.println("D");
        } else
            System.out.println("E");*/

    }
}
