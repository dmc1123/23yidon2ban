import java.util.Random;

/**
 * 打印一组数字，每行5个数字
 */
public class Testfor {
    public static void main(String[] args) {

        /*for (int b = 1; b <= 5; b++) {
            for (int a = 1; a <= 5; a++) {
                System.out.print(b + "\t");
                if (a % 5 == 0) {
                    System.out.println();
                }

            }

        }*/
        /*for (int a = 1; a <= 9; a++) {
            for (int b = 1; b <= a; b++) {
                System.out.print(a + "*" + b + "=" + (a * b) + "\t");


            }
            System.out.println();
        }*/

        /*for (int a = 1; a <= 5; a++) {
            for (int b = 1; b <= 5; b++) {
                if ((a + b) % 2 == 0) {
                    System.out.print("*\t");
                } else {
                    System.out.print("#\t");
                }
            }
            System.out.println();
        }*/

        Random a = new Random();
        int a1 = 0;
        while (true) {
            int b = a.nextInt(101);
            System.out.println(b);
            a1++;
            if (b == 88) {
                break;
            }

        }
        System.out.println("循环次数：" + a1 + "次");


    }
}
