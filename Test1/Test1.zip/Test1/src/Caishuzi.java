/**
 * 猜数字游戏
 */

import java.util.Random;
import java.util.Scanner;

public class Caishuzi {
    public static void main(String[] args) {
        int d = 0;
        Random a1 = new Random();
        System.out.println("整数20以内随机数");
        System.out.print("请输入数字：");


        int b = a1.nextInt((20) + 1);
        while (true) {
            Scanner a = new Scanner(System.in);
            int c = a.nextInt();
            if (c < b) {
                System.out.println("小了");
                d++;
            } else if (c > b) {
                System.out.println("大了");
                d++;
            } else {
                System.out.println("胜利！！！");
                break;
            }
        }
        System.out.println("你的猜测次数：" + d);
    }
}
